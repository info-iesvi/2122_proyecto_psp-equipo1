import React,{ Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import CommentDataService from "../services/comment.service";
import EnviarComentario from "./enviar-comentario";
export default class CommentsList extends Component {
        constructor(props) {
          super(props);
          this.retrieveComments = this.retrieveComments.bind(this);
          this.refreshList = this.refreshList.bind(this);
          this.setActiveComment = this.setActiveComment.bind(this);
      
          this.state = {
            comments: [],
            currentComment: null,
            currentIndex: -1
          };
        }
      
        componentDidMount() {
          this.retrieveComments();
          console.log(this.props.idLibro);
        }
      
      
        retrieveComments() {
            CommentDataService.getAll()
            .then(response => {
              this.setState({
                comments: response.data
              });
              console.log(response.data);
            })
            .catch(e => {
              console.log(e);
            });
        }
      
        refreshList() {
          this.retrieveComments();
          this.setState({
            currentComment: null,
            currentIndex: -1
          });
        }
      
        setActiveComment(comment, index) {
          this.setState({
            currentComment: comment,
            currentIndex: index
          });
        }

        render() {
          const { comments, currentComment, currentIndex } = this.state;
          return(
            <div>
            <div className="row">
              <div className="col-12">
                <EnviarComentario></EnviarComentario>
              </div>
            </div>
            <div className="row ">
              
                <div className="col-12">
                    <div className="contenedorComentarios">
                        <h2>COMENTARIOS</h2>
                        {comments.map((item,index)=>{
                            if(item.isbnLibro==this.props.idLibro){
                                return <div className="row" style={{"marginBottom": "15px"}}>
                                <div className="col-2">
                                    <div className="bloqueUsuario">
                                        <p className="nombreuser">{item.autor}</p>
                                        <p className="fechaPost">{item.fecha}</p>
                                    </div>
                                </div>
                                <div className="col-10">
                                    <div className="bloqueComentario">
                                        <p>{item.contenido}</p>
                                    </div>
                                </div>
                            </div>
                            }
                            
                        })}  
                    </div>
                </div>
            </div>
            </div>
            
        );
        }
      }
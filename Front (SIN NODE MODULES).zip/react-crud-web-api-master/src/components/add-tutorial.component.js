import React, { Component } from "react";
import bookService from "../services/book.service";
export default class AddTutorial extends Component {
    constructor(){
        super();
        this.state={
        titulo:""
        };
      }

    addNewTutorial() {
        var titulo = document.getElementById("inputTitulo").value
        var descripcion = document.getElementById("inputDescripcion").value
        var publicado = document.getElementById("checkPublished").checked
        console.log(titulo);
        console.log(descripcion);
        console.log(publicado);
        var data ={
            titulo:titulo,
            descripcion:descripcion,
            publicado:publicado
        }
        if(titulo==""){
            document.getElementById("alerta1").style.opacity=1;
        }else{
            document.getElementById("alerta2").style.opacity=1; 
            bookService.create(data);   
        }
        
        
        
    }
    render() {
        return(
            
            <div className="container">
                
                <div className="row">
                    <h2>AÑADIR NUEVO TUTORIAL:</h2>
                    <div className="col-12">
                        <label>Título:</label> 
                    </div>
                    <div className="col-12">
                        <input id="inputTitulo" type="text" placeholder="Título..."></input>
                    </div>
                    <div className="col-12">
                        <label>Descripción:</label>
                    </div>
                    <div className="col-12">
                        <textarea id="inputDescripcion" type="text" placeholder="Descripción..."></textarea>
                    </div>
                    <div className="col-6">
                        <label>Publicado:</label>
                        <label class="switch">
                            <input id="checkPublished" type="checkbox"/>
                            <span class="slider round"></span>
                        </label>
                    </div>
                    <div className="col-6">
                        <button
                            className="btn btn-outline-secondary"
                            type="button"
                            onClick={this.addNewTutorial}>
                            Añadir
                        </button>
                        
                    </div>
                    <div className="col-6">
                        <div id="alerta1" class="alert alert-danger" role="alert">
                            No se ha insertado título.
                        </div>
                        <div id="alerta2" class="alert alert-success" role="alert">
                            Elemento insertado.
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
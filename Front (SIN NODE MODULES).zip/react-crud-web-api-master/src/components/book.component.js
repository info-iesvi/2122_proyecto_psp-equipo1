import React,{useContext} from "react";
import { Switch, Route, Link } from "react-router-dom";
export function Book(props){
    //const msg = useContext(UserContext);
    //console.log("Esto es "+msg);
    let imagenUrl="url("+props.imagen+")";
    return(
        <div className="row ">
            <div className="col-12">
            <div style={{ backgroundImage: imagenUrl}} className="portadaLibroListado"></div>
            </div>
            <div className="contenedorLibro ">
                
            <div className="row ">
                <div className="col-6 espaciadoBotonesListado">
                    <Link to={"/libros/" + props.isbn}>
                    <button className="botonVerde">Ver más</button>
                    </Link>
                    
                </div>
                <div className="col-6 espaciadoBotonesListado">
                    <Link to={"/chat/" + props.isbn}>
                        <button className="botonRojo">Chat</button>
                    </Link>
                </div>
                
                
            </div>

            </div>
        </div>
    );
}
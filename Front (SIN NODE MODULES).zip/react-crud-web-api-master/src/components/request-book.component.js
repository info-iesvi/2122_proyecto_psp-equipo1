import React, { Component } from "react";
import BookDataService from "../services/book.service";
import ReactDOM from 'react-dom';





export default class RequestBook extends Component {

    constructor(props) {
        super(props);
        this.sendRequest = this.sendRequest.bind(this);
        this.state = {
          email: null,
          message: null
        };
    }

    onChangeMessage=(event) => {
        this.setState({
            message: event.target.value
        })
    }
    onChangeEmail=(event) => {
        this.setState({
            email: event.target.value
        })
    }

    sendRequest(){
        if(this.state.email == null || this.state.email == ""){
            ReactDOM.render(<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Readme dice:</strong> Indica un email
          </div>, document.querySelector("div div.a"));
            return null;
        }else if(this.state.message == null || this.state.message == ""){
            ReactDOM.render(<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Readme dice:</strong> Indica una sugerencia
          </div>, document.querySelector("div div.a"));
            return null;
        }
        var request = {
            email: this.state.email,
            message: this.state.message
        }
        
       var realizado =  BookDataService.send(request);
       ReactDOM.render(<div class="alert alert-warning alert-dismissible fade show" role="alert">
       <strong>Readme dice:</strong> Se ha enviado la sugerencia. Comprueba tu correo.
      </div>, document.querySelector("div div.a"));
       setTimeout(function(){
        if(realizado){
          window.location.href = 'http://localhost:3000/libros';
         }
       }, 5000
       )
       
        
        


    }

    

    render() {
    
        return (
          
          <div>
          <div className="row">
              <label className="textoRequest">¡Introduce información relevante acerca del libro que quieres que aparezca en nuestra web!</label>
              <hr></hr>
              <div className="formRequest">
                <input type="email" id="emailInput" className="inputRequest" placeholder="Introduce tu email" onChange={this.onChangeEmail}  />
                <input type="text" id="messageInput" className="inputRequest" placeholder="Indica el libro" onChange={this.onChangeMessage} />
                <button type="button" className="botonAmarillo" onClick={this.sendRequest}>Enviar</button>
              </div>
            
          </div>
          <div className="filaBackDeLibros"></div>
          <div class="a"></div>
          </div>
        );
      }
}
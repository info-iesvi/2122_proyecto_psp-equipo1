import React,{ useState, useEffect } from "react";
import BookDataService from "../services/book.service";
import { Switch, Route, Link } from "react-router-dom";
import CommentsList from "./commentslist.component";
export function PostBook(){

    const [titleBook, setTitleBook] = useState("");
    const [descriptionBook, setDescriptionBook] = useState("");
    const [authorBook, setAuthorBook] = useState("");
    const [launchDateBook, setLaunchDateBook] = useState("");
    const [valorationBook, setValorationBook] = useState(0);
    const [imageBook, setImageBook] = useState("");

    var full_url = document.URL; // Get current url
    var url_array = full_url.split('/') // Split the string into an array with / as separator
    var id = url_array[url_array.length-1];

    const idLibroActual = id;
    const anoFecha = 1986;

    useEffect(() => {    
        retrieveBook();
        
    });
    
    function retrieveBook() {
        var full_url = document.URL; // Get current url
        var url_array = full_url.split('/') // Split the string into an array with / as separator
        var id = url_array[url_array.length-1];
        
        BookDataService.get(id)
            .then(response => {
                setTitleBook(response.data.titulo);
                setDescriptionBook(response.data.descripcion);
                setAuthorBook(response.data.autor);
                setLaunchDateBook(response.data.fechaCreacion);
                setValorationBook(response.data.valoracion);
                setImageBook("url("+response.data.imagen+")");
            })
            .catch(e => {
            console.log(e);
            });
    }

/*
{titleBook}
{descriptionBook}
{authorBook}
{launchDateBook}
{valorationBook}
{imageBook}
*/

    return(
        <div>
    
        <div className="row ">
            <div className="col-12">
                <h1 className="tituloPostLibro">{titleBook}</h1>
            </div>
            <div className="col-3">
                <div style={{ backgroundImage: imageBook}} className="imagenPost"></div>
            </div>
            <div className="col-8">
                <div className="contenedorTextoPost">
                    <p>{descriptionBook}</p>
                </div>
            </div>
        </div>
        <div className="row miFilaEtiquetas">
            <div className="col-3 offset-9">
                <div id="etiquetaFecha">
                    {anoFecha}
                </div>
                <div id="etiquetAutor">
                    {authorBook}
                </div>
            </div>
        </div>
        
        <CommentsList idLibro={idLibroActual}></CommentsList>
        </div>
    );
}
import React,{ Component } from "react";
import PersonDataService from "../services/person.service";
import CommentDataService from "../services/comment.service";
import { Switch, Route, Link } from "react-router-dom";
import { render } from "@testing-library/react";
export default class EnviarComentario extends Component{

    constructor(props) {
        super(props);
        this.state = {
            persons: []
        };
        this.EnviarComentario = this.EnviarComentario.bind(this);
    }
    componentDidMount(){
        PersonDataService.getAll()
        .then(response => {
            this.setState({
                persons: response.data,
            });
            console.log(this.state.persons);
            
        })
        .catch(e => {
            console.log(e);
        });
    }
    makeid(length) {
        var result           = '';
        var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for ( var i = 0; i < length; i++ ) {
          result += characters.charAt(Math.floor(Math.random() * 
     charactersLength));
       }
       return result;
    }
    EnviarComentario(){
        var full_url = document.URL; // Get current url
        var url_array = full_url.split('/') // Split the string into an array with / as separator
        var id = url_array[url_array.length-1];
        let usuario= document.getElementById("inputUsuario").value;
        let comentarioAEnviar= document.getElementById("inputComentario").value;
        let usuarioExiste = false;
        let idUser = "";
        let nombre = "";
        let apellidos = "";
        let listaComentarios=[];
        let clave = "";
        let email = "";
        this.state.persons.forEach(element=>{
            if(element.username==usuario ){
                usuarioExiste= true;
                idUser = element.dni;
                nombre = element.nombre;
                apellidos = element.apellidos;
                listaComentarios = element.listaComentarios;
                clave = element.clave;
                email = element.correo;

            }
            
        })
        if(usuario==""){
            alert("No se ha establecido ningun usuario.")
        }
        if(comentarioAEnviar==""){
            alert("No se ha establecido ningún comentario nuevo que enviar.")
        }
        if(usuarioExiste){
            let idDeComentarioACrear = this.makeid(40);
            let fechaactual = new Date();
            let dia = fechaactual.getDate();
            if(dia<10){
                dia = "0"+dia
            }
            let mes = (fechaactual.getMonth())+1;
            if(mes<10){
                mes = "0"+mes
            }
            let anio = fechaactual.getFullYear();
            let fechaCompleta= anio+"-"+dia+"-"+mes
            
            
            var data ={
                fecha:fechaCompleta,
                contenido:comentarioAEnviar,
                autor:usuario,
                isbnLibro:id
            }
            CommentDataService.create(data)
            
            //agregando el dato en el microservicio del usuario
            listaComentarios.push(idDeComentarioACrear);
            console.log(listaComentarios)
            
            var dataUser ={
                nombre:nombre,
                apellidos:apellidos,
                correo:email,
                clave:clave,
                listaComentarios:listaComentarios,
                listaLibrosLeidos:[],
                dni:idUser,
                username:usuario
            }

            PersonDataService.update(idUser,dataUser)

            
        }else{
            alert("No existe ese usuario.")
        }
    }
    render(){
        return(
            <div className="bloqueEnviarComentario">
                <div className="row">
                    <div className="col-3">
                        <input id="inputUsuario" placeholder="Usuario" type="text" />
                    </div>
                    <div className="col-7">
                        <input id="inputComentario" placeholder="Comentario" type="text" />
                    </div>
                    <div className="col-2">
                        <button onClick={this.EnviarComentario}>Enviar</button>
                    </div>
                </div>
            </div>
        );
    }
    
}
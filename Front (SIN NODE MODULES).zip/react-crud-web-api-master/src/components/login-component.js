import React,{ Component } from "react";
import PersonDataService from "../services/person.service";
import sha256 from 'crypto-js/sha256';
import { isElementOfType } from "react-dom/test-utils";
import { Switch, Route, Link } from "react-router-dom";


export default class loginComponent extends Component {
    
    constructor(props) {
        super(props);
        this.state = {
            persons: []
        };
        this.iniciarSesion = this.iniciarSesion.bind(this);
    }
    
    componentDidMount(){
        PersonDataService.getAll()
        .then(response => {
            this.setState({
                persons: response.data,
            });
            console.log(this.state.persons);
            
        })
        .catch(e => {
            console.log(e);
        });
        }

    iniciarSesion(){
        let username = document.getElementById("inputUsername").value;
        let clave = document.getElementById("inputClave").value;
        let claveEncriptada = sha256(clave);

        let fechaactual = new Date();
            let dia = fechaactual.getDate();
            if(dia<10){
                dia = "0"+dia
            }
            let mes = (fechaactual.getMonth())+1;
            if(mes<10){
                mes = "0"+mes
            }
            let anio = fechaactual.getFullYear();
            let fechaCompleta= anio+"-"+dia+"-"+mes
            let datoAEnviar= username+" ha iniciado sesión en el día: "+fechaCompleta
        let valida = false;
        let claveUser = "";
        this.state.persons.forEach(element=>{
            if(element.clave != null && element.clave != ""){
                if(element.clave==claveEncriptada){
                    if(element.username==username){
                        valida=true;
                        var dataLog={
                            dato:datoAEnviar
                        }
                        PersonDataService.logUser(dataLog)
                        .then(response => {
                            
                        })
                        .catch(e => {
                            console.log(e);
                        });
                    }
                }
            }
            
        })

        if(valida){
            alert("Bienvenid@!")
            document.getElementById("UserLogin").innerHTML = username;
            document.getElementById("botonLogin").style.display="none";
            document.getElementById("botonLogout").style.display="block";
        }else{
            alert("Clave o Username no válidos")
        }
    }
    render() {
        return (
            <div id="preContenedorLoginReal">
                <div id="contenedorLoginReal">
                    <div className="row">
                        <div className="col-12">
                            <label>Username</label>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12">
                            <input id="inputUsername" type="text"></input>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12">
                            <label>Clave</label>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12">
                            <input id="inputClave" type="password"></input>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12">
                            <button className="botonCrearUser" onClick={this.iniciarSesion}>Acceder</button>
                            <Link to="/add"><button className="botonCrearUser">Registrarse</button></Link>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
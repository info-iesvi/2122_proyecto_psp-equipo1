import http from "../http-common-book";

class BookDataService {
  getAll() {
    return http.get("/libros");
  }

  get(id) {
    return http.get(`/libros/${id}`);
  }

  create(data) {
    return http.post("/libros", data);
  }

  update(id, data) {
    return http.put(`/libros/${id}`, data);
  }

  delete(id) {
    return http.delete(`/libros/${id}`);
  }

  deleteAll() {
    return http.delete(`/libros`);
  }

  findByTitle(title) {
    return http.get(`/libros?title=${title}`);
  }
  send(request) {
    return http.post("/libros/request", request);
  }
}

export default new BookDataService();
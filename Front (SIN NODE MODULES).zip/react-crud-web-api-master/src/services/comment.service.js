import http from "../http-common-comment";

class CommentDataService {
  getAll() {
    return http.get("/comentario");
  }

  get(id) {
    return http.get(`/comentario/${id}`);
  }

  create(data) {
    return http.post("/comentario", data);
  }

  update(id, data) {
    return http.put(`/comentario/${id}`, data);
  }

  delete(id) {
    return http.delete(`/comentario/${id}`);
  }

  deleteAll() {
    return http.delete(`/comentario`);
  }

  findByTitle(title) {
    return http.get(`/comentario?title=${title}`);
  }

  
}

export default new CommentDataService();
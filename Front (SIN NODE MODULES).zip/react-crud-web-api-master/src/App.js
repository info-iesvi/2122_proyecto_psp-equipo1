import React, { Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import logo from "./images/logoReadmine.png";
import AddTutorial from "./components/add-tutorial.component";
import EditTutorial from "./components/edit-tutorial.component";
import Tutorial from "./services/book.service";
import BooksList from "./components/books-list.component";
import ChatRoom from "./components/chat-component";
import RequestBook from "./components/request-book.component";
import {PostBook} from "./components/individual.post.book.component"
import addUserComponent from "./components/addUser-component"
import loginComponent from "./components/login-component"
import PersonDataService from "./services/person.service";

class App extends Component {
  cerrarSesion(){
    let usuarioQueCieraLaSesion=document.getElementById("UserLogin").innerText;
    alert("Has cerrado sesión "+usuarioQueCieraLaSesion);
    document.getElementById("UserLogin").innerHTML = "";
    document.getElementById("botonLogin").style.display="block";
    document.getElementById("botonLogout").style.display="none";
    let fechaactual = new Date();
    let dia = fechaactual.getDate();
    if(dia<10){
        dia = "0"+dia
    }
    let mes = (fechaactual.getMonth())+1;
    if(mes<10){
        mes = "0"+mes
    }
    let anio = fechaactual.getFullYear();
    let fechaCompleta= anio+"-"+dia+"-"+mes
    let datoAEnviar= usuarioQueCieraLaSesion+" ha cerrado sesión en el día: "+fechaCompleta
    var dataLog={
      dato:datoAEnviar
    }
    PersonDataService.logUser(dataLog)
    .then(response => {
        
    })
    .catch(e => {
        console.log(e);
    });
  }
  render() {
    return (
      <div>
        <nav className="navbar navbar-expand navbar-dark bg-dark">
          
          <div className="navbar-nav mr-auto">
            <li className="nav-item">
              <div>
              <img src={logo}/>
              </div>
              <Link to={"/libros"} className="nav-link">
                Inicio
              </Link>
            </li>
          </div>
          <Link to={"/login"}>
            <h4>     
              <button onClick={this.cerrarSesion} id="botonLogout">Cerrar sesión</button>
            </h4>
            <h4>     
              <button id="botonLogin">Iniciar sesión</button>
            </h4>
          </Link>
          <h4 id="UserLogin"></h4>
        </nav>

        <div className="container mt-3">
          <Switch>
            <Route exact path={["/", "/libros"]} component={BooksList} />
            <Route path={["/libros/:id"]} component={PostBook} />
            <Route path="/chat/:id" component={ChatRoom} />
            <Route path="/request" component={RequestBook}/>
            <Route path="/add" component={addUserComponent} /> 
            <Route path="/login" component={loginComponent} /> 
          </Switch>
        </div>
      </div>
    );
  }
}

export default App;

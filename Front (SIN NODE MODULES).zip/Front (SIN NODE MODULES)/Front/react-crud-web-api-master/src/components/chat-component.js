import React, { useEffect, useState } from 'react'
import {over} from 'stompjs';
import SockJS from 'sockjs-client';
import './chat.css';
import BookDataService from "../services/book.service";

//Declaración de cliente STOMP
var stompClient =null;
//Clase función de chat
const ChatRoom = () => {
    //Declaración de constantes para establecer que chat mapear, si privado o público a la hora de enviar mensajes
    const [privateChats, setPrivateChats] = useState(new Map());     
    const [publicChats, setPublicChats] = useState([]); 
    const [tab,setTab] =useState("CHATROOM");
    //DEclarar variables relevantes para el usuario como el nombre, estado y mensajes
    const [userData, setUserData] = useState({
        username: '',
        receivername: '',   
        connected: false,
        message: ''
      });
    useEffect(() => {
      console.log(userData);
    }, [userData]);

    //Función para conectarse al socket servidor de mensajes
    const connect =()=>{
        //A través de la importación SockJS, nos conectamos al socket servidor indicado por la url. Esta petición será recogida por una aplicación Spring Boot
        let Sock = new SockJS('http://localhost:8080/ws');
        //Inicializar el cliente stomp
        stompClient = over(Sock);
        stompClient.connect({},onConnected, onError);
    }
    

    //Función que lo llama el método connect, para establecer el usuario como conectado y conectarse a los chat STOMP
    const onConnected = () => {
        setUserData({...userData,"connected": true});
        stompClient.subscribe('/chatroom/public', onMessageReceived);
        stompClient.subscribe('/user/'+userData.username+'/private', onPrivateMessage);
        userJoin();
    }

    //Función llamado por onConnected, que envía al servidor que el usuario con nombre indicado se ha unido con éxito.
    const userJoin=()=>{
          var chatMessage = {
            senderName: userData.username,
            status:"JOIN"
          };
          stompClient.send("/app/message", {}, JSON.stringify(chatMessage));
    }

    //Función en el que se recibe los mensajes enviados por el chat público
    const onMessageReceived = (payload)=>{
        var payloadData = JSON.parse(payload.body);
        switch(payloadData.status){
            case "JOIN":
                if(!privateChats.get(payloadData.senderName)){
                    privateChats.set(payloadData.senderName,[]);
                    setPrivateChats(new Map(privateChats));
                }
                break;
            case "MESSAGE":
                publicChats.push(payloadData);
                setPublicChats([...publicChats]);
                break;
        }
    }
    
    //Función en el que se reciben los mensajes enviados pro privado
    const onPrivateMessage = (payload)=>{
        console.log(payload);
        var payloadData = JSON.parse(payload.body);
        if(privateChats.get(payloadData.senderName)){
            privateChats.get(payloadData.senderName).push(payloadData);
            setPrivateChats(new Map(privateChats));
        }else{
            let list =[];
            list.push(payloadData);
            privateChats.set(payloadData.senderName,list);
            setPrivateChats(new Map(privateChats));
        }
    }

    //Función llamada por otras para mostrar posibles errores
    const onError = (err) => {
        console.log(err);
        
    }

    //Función que cambia la constante "mensaje" del usuario cuando este escribe algo en
    //la caja de texto para escribir mensajes. DIcha constante será la usada para recoger el mensaje y enviarlo
    const handleMessage =(event)=>{
        const {value}=event.target;
        setUserData({...userData,"message": value});
    }
    //Función para enviar mensajes al chat público
    const sendValue=()=>{
            if (stompClient) {
              var chatMessage = {
                senderName: userData.username,
                message: userData.message,
                status:"MESSAGE"
              };
              console.log(chatMessage);
              stompClient.send("/app/message", {}, JSON.stringify(chatMessage));
              setUserData({...userData,"message": ""});
            }
    }

    //Función para enviar mensajes al chat privado
    const sendPrivateValue=()=>{
        if (stompClient) {
          var chatMessage = {
            senderName: userData.username,
            receiverName:tab,
            message: userData.message,
            status:"MESSAGE"
          };
          
          if(userData.username !== tab){
            privateChats.get(tab).push(chatMessage);
            setPrivateChats(new Map(privateChats));
          }
          stompClient.send("/app/private-message", {}, JSON.stringify(chatMessage));
          setUserData({...userData,"message": ""});
        }
    }

    //Función para recoger el nombre de usuario introducido en la caja de texto para el mismo y guardarlo en la constante "username" del usuario.
    const handleUsername=(event)=>{
        const {value}=event.target;
        setUserData({...userData,"username": value});
    }

    //Función que llama al método connect y es llamada por el botón ""Entrar al chat"
    const registerUser=()=>{
        connect();
    }
    return (
        <div className="row">
            {userData.connected?
            <div className="chat">
            <div id="portadaLibro" className="col-4"></div>
            <div className="col-8 contenedorChat">
            <div className="bloqueChat">
                <div className='row'>
                
                {tab==="CHATROOM" && <div className="chat-content col-8">
                    <ul className="chat-messages">
                        {publicChats.map((chat,index)=>(
                            <li className={`message ${chat.senderName === userData.username && "self"}`} key={index}>
                                {chat.senderName !== userData.username && <div className="avatar">{chat.senderName}</div>}
                                <div className="message-data">{chat.message}</div>
                                {chat.senderName === userData.username && <div className="avatar self">{chat.senderName}</div>}
                            </li>
                        ))}
                    </ul>
                </div>}
                {tab!=="CHATROOM" && <div className="chat-content col-8">
                    <ul className="chat-messages">
                        {[...privateChats.get(tab)].map((chat,index)=>(
                            <li className={`message ${chat.senderName === userData.username && "self"}`} key={index}>
                                {chat.senderName !== userData.username && <div className="avatar">{chat.senderName}</div>}
                                <div className="message-data">{chat.message}</div>
                                {chat.senderName === userData.username && <div className="avatar self">{chat.senderName}</div>}
                            </li>
                        ))}
                    </ul>  
                </div>
                }
                <div className="bloqueUsuariosChat col-3">
                    <ul>
                        <li className="tituloLista"><strong>Usuarios</strong></li>
                        <li onClick={()=>{setTab("CHATROOM")}} className={`member ${tab==="CHATROOM" && "active"}`}>Chatroom</li>
                        {[...privateChats.keys()].map((name,index)=>(
                            <li onClick={()=>{setTab(name)}} className={`member ${tab===name && "active"}`} key={index}>{name}</li>
                        ))}
                    </ul>
                </div>
                </div>
                
            </div>
            {tab==="CHATROOM" &&
            <div className="send-message">
                <input type="text" className="input-message" placeholder="Escribir..." value={userData.message} onChange={handleMessage} /> 
                <button type="button" className="send-button" onClick={sendValue}>Enviar</button>
            </div>
            }
            {tab!=="CHATROOM" &&
            <div className="send-message">
                <input type="text" className="input-message" placeholder="Escribir..." value={userData.message} onChange={handleMessage} /> 
                <button type="button" className="send-button" onClick={sendPrivateValue}>Enviar</button>
            </div>
            }
                
            </div>
            
            </div>
            :
            <div className="register">
                <input
                    id="user-name"
                    placeholder="Usuario..."
                    name="userName"
                    value={userData.username}
                    onChange={handleUsername}
                    margin="normal"
                  />
                  <button type="button" onClick={registerUser}>
                        Entrar al chat
                  </button>
            </div>}
        </div>
        
        
        )
}

export default ChatRoom
import React,{ Component } from "react";
import PersonDataService from "../services/person.service";
export default class addUserComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            books: []
        };
    }

    insertNewUser(){
        let dni = document.getElementById("inputDNI").value;
        let nombre = document.getElementById("inputNombre").value;
        let apellidos = document.getElementById("inputApellidos").value;
        let username = document.getElementById("inputUsername").value;
        let email = document.getElementById("inputCorreo").value;
        let clave = document.getElementById("inputClave").value;
        let listaLibrosLeidos = null;
        let listaComentarios = null;
        console.log(dni)
        console.log(nombre)
        console.log(apellidos)
        console.log(username)
        console.log(email)
        console.log(clave)

        
        var data ={
            nombre:nombre,
            apellidos:apellidos,
            correo:email,
            clave:clave,
            listaComentarios:null,
            listaLibrosLeidos:null,
            dni:dni,
            username:username
        }
        
        
        PersonDataService.create(data)
        .then(response => {
            console.log(response)
            window.location.href = "login";
          })
          .catch(e => {
            console.log(e);
          });
        
    }
    
    render() {
        return (
            <div id="preContenedorLogin">
            <div id="contenedorLogin">
                <h4>CREAR USUARIO</h4>
                <br></br>
                <div className="row">
                    <div className="col-4">
                        <label>Username</label>
                        <input id="inputUsername" type="text"></input>
                    </div>
                    <div className="col-4">
                        <label>Nombre</label>
                        <input id="inputNombre" type="text"></input>
                    </div>
                    <div className="col-4">
                        <label>Apellidos</label>
                        <input id="inputApellidos" type="text"></input>
                    </div>
                </div>
                <br></br>
                <div className="row">
                    <div className="col-4">
                        <label>DNI</label>
                        <input id="inputDNI" type="text"></input>
                    </div>
                    <div className="col-4">
                        <label>Correo</label>
                        <input id="inputCorreo" type="text"></input>
                    </div>
                    <div className="col-4">
                        <label>Clave</label>
                        <input id="inputClave" type="text"></input>
                    </div>
                </div>
                <div className="row">
                <div className="col-4">
                        <button required="true" onClick={this.insertNewUser} className="botonCrearUser">Crear</button>
                    </div>
                </div>
            </div>
            </div>
        );
    }
}
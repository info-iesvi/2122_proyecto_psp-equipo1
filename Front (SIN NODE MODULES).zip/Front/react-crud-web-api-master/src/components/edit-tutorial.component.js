import React, { Component } from "react";
import bookService from "../services/book.service";
export default class EditTutorial extends Component {
    constructor(){
        super();
        this.state={
            tutorials:null,
            titulo:null,
            descripcion:null,
            publicado:false
        };
      }
      addModifiedTutorial() {
        var titulo = document.getElementById("inputTitulo").value
        var descripcion = document.getElementById("inputDescripcion").value
        var publicado = document.getElementById("checkPublished").checked
        
        console.log(titulo);
        console.log(descripcion);
        console.log(publicado);
        var data ={
            titulo:titulo,
            descripcion:descripcion,
            publicado:publicado
        }
        bookService.update(data)
    }
      componentDidMount(){
        var full_url = document.URL; // Get current url
        var url_array = full_url.split('/') // Split the string into an array with / as separator
        var id = url_array[url_array.length-1];
        var datoTutorial=bookService.get(id)
        .then(response => {
            this.setState({
                tutorials: response.data,
                titulo:response.data.titulo,
                descripcion:response.data.descripcion,
                publicado:response.data.publicado
            });
            console.log(this.state.titulo);
            console.log(this.state.descripcion);
            console.log(this.state.publicado);
            document.getElementById("inputTitulo").setAttribute("value", this.state.titulo);
            document.getElementById("inputDescripcion").setAttribute("value", this.state.descripcion);
            if(this.state.publicado){
                document.getElementById("checkPublished").setAttribute("checked", this.state.publicado);
            }
            
        })
        .catch(e => {
            console.log(e);
        });
        }
      render() {
        return(
            <div className="container">
                <div className="row">
                    <h2>MODIFICAR TUTORIAL:</h2>
                    <div className="col-12">
                        <label>Título:</label> 
                    </div>
                    <div className="col-12">
                        <input id="inputTitulo" type="text" placeholder="Título..."></input>
                    </div>
                    <div className="col-12">
                        <label>Descripción:</label>
                    </div>
                    <div className="col-12">
                        <input id="inputDescripcion" type="text" >
                        </input>
                    </div>
                    <div className="col-6">
                        <label>Publicado:</label>
                        <label class="switch">
                            <input id="checkPublished"  type="checkbox"/>
                            <span className="slider round"></span>
                        </label>
                    </div>
                    <div className="col-6">
                        <button
                            className="btn btn-outline-secondary"
                            type="button"
                            onClick={this.addModifiedTutorial}>
                            Añadir
                        </button>
                    </div>
                </div>
            </div>
        )
    }
}
import React, { Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import logo from "./images/logoReadmine.png";
import AddTutorial from "./components/add-tutorial.component";
import EditTutorial from "./components/edit-tutorial.component";
import Tutorial from "./services/book.service";
import BooksList from "./components/books-list.component";
import ChatRoom from "./components/chat-component";
import RequestBook from "./components/request-book.component";
import {PostBook} from "./components/individual.post.book.component"
import addUserComponent from "./components/addUser-component"
import loginComponent from "./components/login-component"


class App extends Component {
  render() {
    return (
      <div>
        <nav className="navbar navbar-expand navbar-dark bg-dark">
          
          <div className="navbar-nav mr-auto">
            <li className="nav-item">
              <div>
              <img src={logo}/>
              </div>
              <Link to={"/libros"} className="nav-link">
                Inicio
              </Link>
            </li>
          </div>
          <Link to={"/login"}>
            <h4>     
              <button id="botonLogin">Iniciar sesión</button>
            </h4>
          </Link>
        </nav>

        <div className="container mt-3">
          <Switch>
            <Route exact path={["/", "/libros"]} component={BooksList} />
            <Route path={["/libros/:id"]} component={PostBook} />
            <Route path="/chat/:id" component={ChatRoom} />
            <Route path="/request" component={RequestBook}/>
            <Route path="/add" component={addUserComponent} /> 
            <Route path="/login" component={loginComponent} /> 
          </Switch>
        </div>
      </div>
    );
  }
}

export default App;
